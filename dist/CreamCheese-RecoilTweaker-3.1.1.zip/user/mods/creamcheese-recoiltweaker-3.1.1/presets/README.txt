This folder contains all the config files for different presets. To change preset, go into your selected
folder, and copy the config.json file from that folder and copy it to:
CreamCheese-RecoilTweaks/config/
Make sure to replace the file when copying it over so the new values replace the ones you already had.
If you ever want to revert back to the default settings, please use the Default config.json.

Credits to Fontaine for the values provided within his mod for the recoil preset. The preset isn't exactly
the same, but pretty close. If you want his exact recoil system, please download his mod and support his work.
Do not use this preset if you're already using the Realism mod.